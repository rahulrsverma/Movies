//SERVER ROUTES
export const USER_SERVER = '/api/users';

export const API_KEY = '81f7d666450a48be2850d30103316bec';
export const API_URL = 'https://api.themoviedb.org/3/';

export const IMAGE_URL = 'http://image.tmdb.org/t/p/';